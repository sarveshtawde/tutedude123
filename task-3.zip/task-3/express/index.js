const express = require('express');
const fetch = require('node-fetch');
const app = express();

app.get('/', async (req, res) => {
  res.send('<h1>Hello from Express (container)!</h1><p>Use <a href="/fetch">/fetch</a> to call Flask API</p>');
});

app.get('/fetch', async (req, res) => {
  // call backend at /api/hello; note: in production you'd use internal DNS / service discovery.
  // Here ALB routes /api/* to Flask; calling via ALB public URL is possible from client,
  // but server-side call to ALB requires the ALB DNS. For example purposes we return a hint.
  res.json({ note: "Visit /api/hello via ALB (frontend -> backend via browser)." });
});

const port = process.env.PORT || 3000;
app.listen(port, '0.0.0.0', () => console.log(`Express listening on ${port}`));

